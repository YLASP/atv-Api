const Plantation = require('../models/Presenca');

exports.getAllPresencas = async (req, res) => {
    try {
        const presencas = await Presenca.find();
        res.json(presencas);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.createPresencas = async (req, res) => {
    const { name, resumo, localizacao, foto } = req.body;
    const newPresenca = new Presenca({ nome, resumo, localizacao, foto });

    try {
        const savedPresencas = await newPresenca.save();
        res.status(201).json(savedPresenca);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};

exports.updatePresenca = async (req, res) => {
    try {
        const updatedPresenca = await Presenca.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedPresenca);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};

exports.deletePresenca = async (req, res) => {
    try {
        await Plantation.findByIdAndDelete(req.params.id);
        res.json({ message: 'Presenca deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
