function searchVehicle() {
    const model = document.getElementById('vehicleModel').value;
    if (!model) {
        alert('Por favor, insira um modelo de veículo.');
        return;
    }

    const url = `https://vpic.nhtsa.dot.gov/api/vehicles/getmodelsformake/${model}?format=json`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = '';

            if (data.Count === 0) {
                resultsDiv.innerHTML = '<p>Nenhum veículo encontrado para o modelo especificado.</p>';
                return;
            }

            data.Results.forEach(result => {
                const make = result.Make_Name;
                const modelName = result.Model_Name;
                const year = result.Model_Year || 'N/A';
                const description = `<p><strong>Marca:</strong> ${make}<br><strong>Modelo:</strong> ${modelName}<br><strong>Ano:</strong> ${year}</p>`;
                resultsDiv.innerHTML += description;
            });
        })
        .catch(error => {
            console.error('Erro ao buscar dados:', error);
        });
}
